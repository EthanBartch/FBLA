import '/flutter_flow/flutter_flow_util.dart';
import 'misc_widget.dart' show MiscWidget;
import 'package:flutter/material.dart';

class MiscModel extends FlutterFlowModel<MiscWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
