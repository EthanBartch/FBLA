import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyBZHJqqDwXvp3glb4_v2swMPz0MRqJnwn0",
            authDomain: "spendsmart-f5c99.firebaseapp.com",
            projectId: "spendsmart-f5c99",
            storageBucket: "spendsmart-f5c99.appspot.com",
            messagingSenderId: "864952361242",
            appId: "1:864952361242:web:d689b7ac51c2cdf2e34ca3",
            measurementId: "G-2Y5KCDV4T2"));
  } else {
    await Firebase.initializeApp();
  }
}
