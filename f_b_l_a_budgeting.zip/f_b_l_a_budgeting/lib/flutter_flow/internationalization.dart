import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'pt'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? ptText = '',
  }) =>
      [enText, ptText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

/// Used if the locale is not supported by GlobalMaterialLocalizations.
class FallbackMaterialLocalizationDelegate
    extends LocalizationsDelegate<MaterialLocalizations> {
  const FallbackMaterialLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<MaterialLocalizations> load(Locale locale) async =>
      SynchronousFuture<MaterialLocalizations>(
        const DefaultMaterialLocalizations(),
      );

  @override
  bool shouldReload(FallbackMaterialLocalizationDelegate old) => false;
}

/// Used if the locale is not supported by GlobalCupertinoLocalizations.
class FallbackCupertinoLocalizationDelegate
    extends LocalizationsDelegate<CupertinoLocalizations> {
  const FallbackCupertinoLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<CupertinoLocalizations> load(Locale locale) =>
      SynchronousFuture<CupertinoLocalizations>(
        const DefaultCupertinoLocalizations(),
      );

  @override
  bool shouldReload(FallbackCupertinoLocalizationDelegate old) => false;
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

bool _isSupportedLocale(Locale locale) {
  final language = locale.toString();
  return FFLocalizations.languages().contains(
    language.endsWith('_')
        ? language.substring(0, language.length - 1)
        : language,
  );
}

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // initial
  {
    'pxfeuk07': {
      'en': 'FBLA Bank',
      'pt': 'Kitty',
    },
    'xtytwhhl': {
      'en': 'DATA',
      'pt': '',
    },
    'd7h63cn1': {
      'en': 'Expenses',
      'pt': 'Despesas',
    },
    'kcpcr69v': {
      'en': 'Income',
      'pt': 'Renda',
    },
    '0uznn4nj': {
      'en': 'Current Balance',
      'pt': 'Saldo',
    },
    '6z2w3uwy': {
      'en': 'Create',
      'pt': 'Adicionar novo',
    },
    'zt2nzgpp': {
      'en': 'Home',
      'pt': 'Inicio',
    },
  },
  // report
  {
    'pxio3obv': {
      'en': 'Statistics',
      'pt': 'Estatisticas',
    },
    '27cpwyz9': {
      'en': 'OVERVIEW',
      'pt': 'VISÃO GERAL',
    },
    'ohe1klja': {
      'en': 'DETAILS',
      'pt': 'DETALHES',
    },
    'g0u3eplo': {
      'en': 'Statistics',
      'pt': 'Estatisticas',
    },
  },
  // createExpense
  {
    'fpobmyte': {
      'en': 'Income',
      'pt': 'Renda',
    },
    '9acdjdrd': {
      'en': 'Expense',
      'pt': 'Despesa',
    },
    'u0a7tcan': {
      'en': 'Invoice',
      'pt': 'Renda',
    },
    '3klurzok': {
      'en': 'Income/Budget',
      'pt': 'Renda/Despesa',
    },
    'vy8e0ryy': {
      'en': 'Search for an item...',
      'pt': 'Procurar um item...',
    },
    '01q69rbk': {
      'en': 'BILLS',
      'pt': 'Educação',
    },
    'xgex1toh': {
      'en': 'EDUCATION',
      'pt': 'Eletrônicos',
    },
    'wpbca363': {
      'en': 'lSAVINGS',
      'pt': 'Combustível',
    },
    '01ofez8y': {
      'en': 'TRANSPORTATION',
      'pt': 'Mercado',
    },
    'wniujuhd': {
      'en': 'HEALTH',
      'pt': 'Saúde',
    },
    '3755zwmx': {
      'en': 'GAS',
      'pt': 'Poupança',
    },
    'cqknees2': {
      'en': 'GROCERIES',
      'pt': 'Transporte',
    },
    'dnb6be8k': {
      'en': 'Select Category',
      'pt': 'Selecione a Categoria',
    },
    '7trmhkmt': {
      'en': 'Search for an category',
      'pt': 'Pesquisar uma categoria',
    },
    'gwjpp0l1': {
      'en': 'Enter amount',
      'pt': 'Insira o valor',
    },
    'tf6lw3vg': {
      'en': 'Description (Optional)',
      'pt': 'Descrição (opcional)',
    },
    'e0vktzak': {
      'en': 'Add a new',
      'pt': 'Adicionar um novo',
    },
    '58q75359': {
      'en': 'Amount is required',
      'pt': 'O saldo é obrigatório',
    },
    'c842khfl': {
      'en': 'Invalid value for Amount. Ex: 90.50',
      'pt': 'Valor inválido para Saldo. Ex: 90,50',
    },
    'bcchv2ht': {
      'en': 'Please choose an option from the dropdown',
      'pt': 'Escolha uma opção no menu',
    },
    '0jwizuht': {
      'en': 'Field is required',
      'pt': 'Campo é obrigatório',
    },
    '98ardp74': {
      'en': 'Please choose an option from the dropdown',
      'pt': 'Escolha uma opção no menu',
    },
    'zhym1v85': {
      'en': 'ADD',
      'pt': 'Adicionar novo',
    },
    'jjce6u3q': {
      'en': 'Home',
      'pt': 'Inicio',
    },
  },
  // login
  {
    'qggdbtg4': {
      'en': 'FBLA BANK',
      'pt': 'Kitty',
    },
    'kxiutu7a': {
      'en': 'Create Account',
      'pt': 'Criar uma conta',
    },
    'rm2zatw5': {
      'en': 'Create Account',
      'pt': 'Criar uma conta',
    },
    'spa5sk3e': {
      'en': 'Email',
      'pt': 'E-mail',
    },
    'jdmcsqhw': {
      'en': 'Password',
      'pt': 'Senha',
    },
    '7uc0edks': {
      'en': 'Confirm password',
      'pt': 'Confirme sua senha',
    },
    '1wjc7ry3': {
      'en': 'Get Started',
      'pt': 'Iniciar',
    },
    'u6qfqqol': {
      'en': 'Log In',
      'pt': 'Conecte-se',
    },
    'czaqm8sx': {
      'en': 'Log in',
      'pt': 'Bem vindo de volta',
    },
    'iav3i6c0': {
      'en': 'Email',
      'pt': 'E-mail',
    },
    '2y8wc9zo': {
      'en': 'Password',
      'pt': 'Senha',
    },
    '99va8wxa': {
      'en': 'Sign In',
      'pt': 'Entrar',
    },
    '3jpxqy42': {
      'en': 'Home',
      'pt': 'Inicio',
    },
  },
  // searchScreen
  {
    'f6qitlvn': {
      'en': 'Search',
      'pt': 'Pesquise por categorias ou descrição',
    },
    'z0p8gblh': {
      'en': 'Home',
      'pt': 'Inicio',
    },
  },
  // editExpense
  {
    'cgf3ygl7': {
      'en': 'Income',
      'pt': 'Renda',
    },
    'fw9vxr1w': {
      'en': 'Expense',
      'pt': 'Despesa',
    },
    'c8ij0gvp': {
      'en': 'Invoice',
      'pt': 'Renda',
    },
    'hko6ezg3': {
      'en': 'Income/Budget',
      'pt': 'Renda/Despesa',
    },
    'vw8adcit': {
      'en': 'Search for an item...',
      'pt': 'Procurar um item...',
    },
    '8gw9w48m': {
      'en': 'Bills',
      'pt': 'Combustível',
    },
    'x9y9xu7k': {
      'en': 'Education',
      'pt': 'Presentes',
    },
    'liw1djky': {
      'en': 'Savings',
      'pt': 'Mercado',
    },
    'nz1ihdqw': {
      'en': 'Trnsportation',
      'pt': 'Saúde',
    },
    '80ibmr1j': {
      'en': 'Health',
      'pt': 'Instituto',
    },
    'yva1sh8h': {
      'en': 'Gas',
      'pt': 'Lavanderia',
    },
    'bv3dr91r': {
      'en': 'Groceries',
      'pt': 'Manutenção',
    },
    'q8mye2zp': {
      'en': 'Select Category',
      'pt': 'Selecione a Categoria',
    },
    'f0jdrxdm': {
      'en': 'Search for an category',
      'pt': 'Pesquisar uma categoria',
    },
    'ifjlvbhd': {
      'en': 'Enter amount',
      'pt': 'Insira o saldo',
    },
    'vg84m6jc': {
      'en': 'Description (Optional)',
      'pt': 'Descrição (opcional)',
    },
    'rt1ash54': {
      'en': 'Edit',
      'pt': 'Editar',
    },
    'tbhvf5pj': {
      'en': 'Delete',
      'pt': 'Excluir',
    },
    'izjvzi7f': {
      'en': 'Confirm delete',
      'pt': 'Confirmar exclusão',
    },
    'r4m1t0a1': {
      'en': 'Are you sure you want to delete this expense/income?',
      'pt': 'Tem certeza de que deseja excluir esta despesa/receita?',
    },
    '2gh6bfnu': {
      'en': 'Cancel',
      'pt': 'Cancelar',
    },
    '6bd89nbx': {
      'en': 'Confirm',
      'pt': 'Confirmar',
    },
    'z0ydpuso': {
      'en': 'Amount is required',
      'pt': 'O saldo  é obrigatório',
    },
    '0636u1e0': {
      'en': 'Invalid value for Amount. Ex: 90.50',
      'pt': 'Valor inválido para Valor. Ex: 90,50',
    },
    'ayp6tbzf': {
      'en': 'Please choose an option from the dropdown',
      'pt': 'Escolha uma opção no menu suspenso',
    },
    'b2iwa2um': {
      'en': 'Field is required',
      'pt': 'Campo é obrigatório',
    },
    '9rowbj3s': {
      'en': 'Please choose an option from the dropdown',
      'pt': 'Escolha uma opção no menu suspenso',
    },
    '0rsd07xx': {
      'en': 'EDIT',
      'pt': 'Editar',
    },
    'qva4jc6s': {
      'en': 'Home',
      'pt': 'Inicio',
    },
  },
  // Misc
  {
    'jfs6hw9x': {
      'en':
          '\"Persistence is the twin sister of excellence. One is a matter of quality; the other, a matter of time.\" —Marabel Morgan\n',
      'pt': '',
    },
    'b8n9ir35': {
      'en': 'Home',
      'pt': '',
    },
    'qnqe8j91': {
      'en': 'Past 100 Days',
      'pt': '',
    },
    'mc88hl30': {
      'en': 'Expenses',
      'pt': '',
    },
    'wyug4607': {
      'en': 'sfd',
      'pt': '',
    },
    'dhc9nhvd': {
      'en': 'Past 100 Days',
      'pt': '',
    },
    'tl35zvr7': {
      'en': 'Expenses',
      'pt': '',
    },
    '2uf5wtb0': {
      'en': 'sfd',
      'pt': '',
    },
    '3ysmf3kf': {
      'en': 'Days',
      'pt': '',
    },
    '48udyplb': {
      'en': 'Past 100 Days',
      'pt': '',
    },
    'i1g1zlkx': {
      'en': 'Expenses',
      'pt': '',
    },
    '0812h38h': {
      'en': 'sfd',
      'pt': '',
    },
    'pkjtyblw': {
      'en': 'Days',
      'pt': '',
    },
    '2lgb3o3c': {
      'en': 'Page Title',
      'pt': '',
    },
    'z8xozhob': {
      'en': 'Home',
      'pt': '',
    },
  },
  // month_picker_dialog
  {
    'kitcrcil': {
      'en': 'PICK A MONTH',
      'pt': 'ESCOLHA UM MÊS',
    },
    'oaiocrqj': {
      'en': 'ALL TIME',
      'pt': 'TUDO',
    },
  },
  // user_name_icon
  {
    '6qw7pk5q': {
      'en': 'J',
      'pt': 'M',
    },
  },
  // EnterSource
  {
    '732r7xfc': {
      'en': 'Text Box',
      'pt': '',
    },
    '3vyi1xjd': {
      'en': 'BTN',
      'pt': '',
    },
    'k9oiss4z': {
      'en': 'BTN',
      'pt': '',
    },
    'ixce2ath': {
      'en': 'BTN',
      'pt': '',
    },
  },
  // Miscellaneous
  {
    'r69iwd0l': {
      'en': '',
      'pt': '',
    },
    'rkyis8o4': {
      'en': '',
      'pt': '',
    },
    'numtrt8f': {
      'en': '',
      'pt': '',
    },
    'wl1usgju': {
      'en': '',
      'pt': '',
    },
    'lm8j8et6': {
      'en': '',
      'pt': '',
    },
    'rnrk0bfd': {
      'en': '',
      'pt': '',
    },
    'j3r89ndo': {
      'en': '',
      'pt': '',
    },
    'x5w2ijmx': {
      'en': '',
      'pt': '',
    },
    'lybzc8c2': {
      'en': '',
      'pt': '',
    },
    '19dnv8il': {
      'en': '',
      'pt': '',
    },
    'zh3lr2vx': {
      'en': '',
      'pt': '',
    },
    'a1xfs6jd': {
      'en': '',
      'pt': '',
    },
    'bbko9ojm': {
      'en': '',
      'pt': '',
    },
    'jgkscrvd': {
      'en': '',
      'pt': '',
    },
    'sik4hrh7': {
      'en': '',
      'pt': '',
    },
    '06rxox15': {
      'en': '',
      'pt': '',
    },
    'r9n52d32': {
      'en': '',
      'pt': '',
    },
    'qcbabdmg': {
      'en': '',
      'pt': '',
    },
    'n1pa6jdj': {
      'en': '',
      'pt': '',
    },
    '7w9n0v0l': {
      'en': '',
      'pt': '',
    },
    'p3i4pkvu': {
      'en': '',
      'pt': '',
    },
    'hfw7zoap': {
      'en': '',
      'pt': '',
    },
    '848m7i32': {
      'en': '',
      'pt': '',
    },
    'v6v3h8su': {
      'en': '',
      'pt': '',
    },
  },
].reduce((a, b) => a..addAll(b));
