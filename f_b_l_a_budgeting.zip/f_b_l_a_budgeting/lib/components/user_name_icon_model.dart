import '/flutter_flow/flutter_flow_util.dart';
import 'user_name_icon_widget.dart' show UserNameIconWidget;
import 'package:flutter/material.dart';

class UserNameIconModel extends FlutterFlowModel<UserNameIconWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
