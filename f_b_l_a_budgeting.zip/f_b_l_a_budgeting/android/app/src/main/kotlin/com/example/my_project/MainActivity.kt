package com.br.cardosofgui.kittyexpensemanagement

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
